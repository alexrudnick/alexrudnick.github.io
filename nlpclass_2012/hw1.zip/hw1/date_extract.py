#!/usr/bin/env python3

"""
Extract all the dates from the text files listed on the command line. Also
print out all the months from those dates.

Run like this:
python3 date_extract.py wikinews/*.txt

Your output should look like:
date: Tuesday, August 2, 2005
month: August
date: Sunday, March 27, 2005
month: March

... and so on.
"""

import re
import sys

def main():
    ## TODO(you): write the appropriate regular expression here. It doesn't
    ## have to ensure valid days of the week or valid months, but it should
    ## find dates that look like "Thursday, July 19, 2007" or similar.
    ## It could also find dates like "Yarnday, Foo 2, 5567" (that would be
    ## fine). We're assuming that names of days in English always end with
    ## "day".

    ## Look at the Python regular expression docs, they have good examples!
    ## http://docs.python.org/py3k/library/re.html

    datepattern = r"YOUR REGULAR EXPRESSION GOES HERE"

    ## for each filename listed...
    for fn in sys.argv[1:]:
        with open(fn) as infile:
            for line in infile:
                match = re.search(datepattern, line)
                if not match:
                    continue

                ## TODO(you): Use parentheses to "capture" the month in the
                ## pattern above. Print it out here.
                print("date:", match.group(0))
                print("month:", match.group(1))

if __name__ == "__main__": main()
