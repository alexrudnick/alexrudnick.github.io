#!/usr/bin/env python3

"""
Really simple Naïve Bayes classifier for b490 NLP at Indiana University.
"""

from collections import defaultdict
from functools import reduce
from operator import mul
from operator import itemgetter
import sys
import random

DEBUG=False

def train(instances):
    """Takes some instances and learn the probabilities P(c) for each class and
    P(f=v|c) for each feature/value/class."""

    assert(len(instances) > 0)
    num_features = len(instances[0]) - 1

    ## Go through the instances and count how many classes there are.
    all_classes = set([instance[-1] for instance in instances])
    num_classes = len(all_classes)

    class_counts = defaultdict(lambda:0)
    conditional_counts = {}

    ## For smoothing purposes, pretend that we've seen every value in the data
    ## set, and also the UNSEEN value, once.
    for feat_num in range(num_features):
        values = set([instance[feat_num] for instance in instances])
        values.add("UNSEEN")
        for value in values:
            for cl in all_classes:
                conditional_counts[(feat_num, value, cl)] = 1

    ## Now actually count up what we've seen in the dataset. For each instance,
    ## increment the count of that instance's class and also the counts of the
    ## feature values for that class.
    for instance in instances:
        # TODO(you): finish this loop so that class_counts and
        # conditional_counts count up how many times each class happens, and
        # each feature/value pair happens for each class.
        cl = instance[-1]

        ## for each feature for this instance, add to the counts for this
        ## feature.
        for feat_num in range(num_features):
            pass

    ## Compute the priors for each class. That's just the fraction of the time
    ## this class appears in the dataset.
    ## TODO(you): fix this part up so that it works; instead of having equal
    ## probability, make each class have probability proportional to how often it
    ## occurs in the training set.
    class_priors = {}
    for cl in all_classes:
        class_priors[cl] = 1 / num_classes

    ## Compute conditional probabilities for each feature setting, conditioned
    ## on each class.
    conditionals = {}
    for feat_num in range(num_features):
        values = set(instance[feat_num] for instance in instances)
        values.add("UNSEEN")
        for cl in all_classes:
            for value in values:
                ## TODO(you): Compute the conditional probability for this
                ## feature having this value, given the current class.

                # top = how to compute the numerator for conditional probability?
                # bottom = ... and how to compute denominator? ...
                conditionals[(feat_num, value, cl)] = 1 / len(values)

            ## check that the possibilities for this feature sum to 1.0.
            if DEBUG:
                keys = [key for key in conditionals.keys()
                        if key[2] == cl and key[0] == feat_num]
                total = sum([conditionals[key] for key in keys])
                assert abs(1.0 - total) < 0.001
    return class_priors, conditionals

def product(numbers):
    """Multiply a list of numbers."""
    return reduce(mul, numbers)

def normalize(numbers):
    """Return a list of numbers that sums to 1.0."""
    total = sum(numbers)
    return [num / total for num in numbers]

def classify(instance, class_priors, conditionals):
    """Return the most probable class for this instance."""

    # As we know from Bayes Rule,
    # P(class|features) = P(features|class) * P(class) / P(features)
    # Except that since P(features) is constant across every class, we don't
    # care about it! We're just looking for the most probable class! So we
    # never calculate that denominator.
    classes = class_priors.keys()
    num_features = len(instance) - 1

    ## TODO(you): For each class, calculate a score for that class, where the
    ## score is equal to P(features|class) * P(class).
    ## That's just the numerator for the equation above.


    # Keep in mind that P(features|class) is just:
    # P(f1=v1|cl) * P(f2=v2|cl) ... (and so on)
    # due to our independence assumption. P(f=v|cl) is already stored in the
    # conditionals dictionary as conditionals[(f,v,cl)].

    # So a good plan for this is: loop over every class.
    # For each class, loop over every feature and look up the probability of
    # that feature being set to that value, assuming the current class.
    # Multiply all of those together to get P(features|class). Then multiply
    # all of that by P(class) !
    
    # Then return the class with the highest P(features|class) * P(class).
    for cl in classes:
        for feat_num in range(num_features):
            key = (feat_num, instance[feat_num], cl)
            if key not in conditionals:
                key = (feat_num, "UNSEEN", cl)
            conditional = conditionals[key]

    ## TODO(you): don't return a random class, return the most probable one!
    return random.choice(list(classes))

def load_dataset(fn):
    """Open a simple csv file and return a list of its contents, where each
    line is a list of strings."""
    with open(fn) as infile:
        lines = infile.readlines()
        out = []
        for line in lines:
            splitted = line.strip().split(",") 
            out.append(splitted)
        return out

def print_probabilities(class_priors, conditionals):
    print("** class priors **")
    for cl in class_priors:
        print("  {0}: {1}".format(cl, class_priors[cl]))

    print("** conditional probabilities **")
    for fv in sorted(list(conditionals.keys()), key=itemgetter(2,0,1)):
        print("  {0}: {1}".format(fv, conditionals[fv]))

def main():
    if len(sys.argv) != 3:
        print("usage: %s training.csv test.csv" % (sys.argv[0],))

    training = load_dataset(sys.argv[1])
    class_priors, conditionals = train(training)

    if DEBUG: print_probabilities(class_priors, conditionals)

    test = load_dataset(sys.argv[2])
    correct = 0
    for instance in test:
        prediction = classify(instance, class_priors, conditionals)
        actual = instance[-1]
        if actual == prediction:
            correct += 1
        else:
            print("wrong for instance:", instance, " predicted:", prediction)
    accuracy = correct / len(test)
    print("accuracy over test set: %0.3f" % (accuracy,))

if __name__ == "__main__": main()
